<?php

require __DIR__.'/src/Autoload.php';

//$name = (new person)->setName(1);

$autoload = new KarlinhoFig\Autoload;
$autoload->register();
$autoload->AddNamespace('KarlinhoFig', 'src');

$person = new KarlinhoFig\People\Person;
$person->setName('karlinho');
$person->setAge(24);
$person->setWeight(64.2);

var_dump($person);
<?php 

namespace  KarlinhoFig;

/** 
* Um exemplo de implementação de propósito geral que inclui a 
funcionalidade 
opcional * de permitir vários diretórios base para um único prefixo de 
namespace *. * 
* Dado um pacote foo-bar de classes no sistema de arquivos nos seguintes 
* caminhos ... 
* 
* / caminho / para / packages / foo-bar / 
* src / 
* Baz.php # Foo \ Bar \ Baz 
* Qux / 
* Quux.php # Foo \ Bar \ Qux \ Quux 
* tests / 
* BazTest.php # Foo \ Bar \ BazTest 
* Qux / 
* QuuxTest.php # Foo \ Bar \ Qux \ QuuxTest 
*
* ... adicione o caminho para os arquivos de classe para o prefixo de namespace \ Foo \ Bar \ da 
seguinte forma: 
* 
* <? php 
* // instanciar o carregador 
* $ loader = new \ Example \ Psr4AutoloaderClass; 
* 
* // registrar o autoloader 
* $ loader-> register (); 
* 
* // registra os diretórios base para o prefixo do namespace 
* $ loader-> addNamespace ('Foo \ Bar', '/ caminho / para / packages / foo-bar / src'); 
* $ loader-> addNamespace ('Foo \ Bar', '/ path / to / packages / foo-bar / tests'); 
* 
* A linha a seguir faria com que o autoloader tentasse carregar a 
classe * \ Foo \ Bar \ Qux \ Quux de /path/to/packages/foo-bar/src/Qux/Quux.php: 
*
* <? php 
* new \ Foo \ Bar \ Qux \ Quux; 
* 
* A linha a seguir faria com que o autoloader tentasse carregar a 
classe * \ Foo \ Bar \ Qux \ QuuxTest de /path/to/packages/foo-bar/tests/Qux/QuuxTest.php: 
* 
* <? Php 
* novo \ Foo \ Bar \ Qux \ QuuxTest; 
*/ 
class Autoload
{
    /** 
     * Um array associativo em que a chave é um prefixo de namespace e o valor 
     * é um array de diretórios base para classes naquele namespace. 
     * 
     * @var array 
     */ 
    protected  $prefixes = array();

    /** 
     * Registra o carregador com a pilha do autoloader SPL. 
     * 
     * @return void 
     */ 
    public  function  register ()
    {
        spl_autoload_register ( array ( $this , 'loadClass' ));
    }

    /** 
     * Adiciona um diretório base para um prefixo de namespace. 
     * 
     * @param string $ prefix O prefixo do namespace. 
     * @param string $ base_dir Um diretório base para arquivos de classe no 
     * namespace. 
     * @param bool $ prepend Se verdadeiro, adiciona o diretório base à pilha 
     * em vez de anexá-lo; isso faz com que seja pesquisado primeiro, e 
     não por último. 
     * @Return vazio 
     */ 
    public  function  addNamespace ( $prefix , $BASE_DIR , $preceder = false )
    {
        // normaliza o prefixo de namespace 
        $prefix = trim ( $prefix , '\\' ). '\\' ;

        // normaliza o diretório base com um separador final 
        $base_dir = rtrim ( $base_dir , DIRECTORY_SEPARATOR ). '/' ;

        // inicializa o array de prefixo de namespace 
        if ( isset ( $this -> prefixos [ $prefix ]) === false ) {
             $this -> prefixos [ $prefix ] = array ();
        }

        // reter o diretório base para o prefixo namespace 
        se ( $preceder ) {
             array_unshift ($presente ->prefixos [ $prefix ], $BASE_DIR );
        } else {
             array_push ( $this ->prefixos [ $prefix ], $base_dir );
        }
    }

    /** 
     * Carrega o arquivo de classe para um determinado nome de classe. 
     * 
     * @param string $ class O nome totalmente qualificado da classe. 
     * @return mixed O nome do arquivo mapeado em caso de sucesso ou booleano falso em 
     * falha. 
     */ 
    public  function  loadClass ( $class )
    {
        // o prefixo do namespace atual 
        $prefix = $class ;

        // retroceda nos nomes de namespace do 
        // nome de classe 
        totalmente qualificado para encontrar um nome de arquivo mapeado while ( false ! == $pos = strrpos ( $prefix , '\\' )) {

            // retém o separador de espaço de nomes final no prefixo 
            $prefix = substr ( $class , 0 , $pos + 1 );

            // o resto é o nome da classe relativa 
            $relative_class = substr ( $class , $pos + 1 );

            // tenta carregar um arquivo mapeado para o prefixo e classe relativa 
            $mapped_file = $this -> loadMappedFile ( $prefix , $relative_class );
            if ( $mapped_file ) {
                 return  $mapped_file ;
            }

            // remove o separador de espaço de nomes final para a próxima iteração 
            // de strrpos () 
            $prefix = rtrim ( $prefix , '\\' );
        }

        // nunca encontrou um arquivo mapeado 
        return  false ;
    }

    /** 
     * Carrega o arquivo mapeado para um prefixo de namespace e classe relativa. 
     * 
     * @param string $ prefix O prefixo do namespace. 
     * @param string $ relative_class O nome relativo da classe. 
     * @return mixed Boolean false se nenhum arquivo mapeado pode ser carregado, ou o 
     * nome do arquivo mapeado que foi carregado. 
     */ 
    função protegida  loadMappedFile ( $prefix , $relative_class ) 
    {
        // existe algum diretório base para este prefixo de namespace?
        if ( isset ( $this -> prefixos [ $prefix ]) === false ) {
             return  false ;
        }

        // procure nos diretórios base por este prefixo de namespace 
        foreach ( $this -> prefixos [ $prefix ] as  $base_dir ) {

            // substitua o prefixo do namespace pelo diretório base, 
            // substitua os separadores do namespace pelos separadores do diretório 
            // no nome da classe relativa, acrescente .php 
            $file = $base_dir 
                  . str_replace ( '\\' , '/' , $relative_class )
                  . '.php' ;

            // se o arquivo mapeado existe, exige-o 
            if ( $this -> requireFile ( $file )) {
                 // sim, terminamos 
                return  $file ;
            }
        }

        // nunca o encontrei 
        return  false ;
    }

    /** 
     * Se um arquivo existir, solicite-o do sistema de arquivos. 
     * 
     * @param string $ file O arquivo a ser requerido. 
     * @return bool True se o arquivo existir, false se não existir. 
     */ 
    função protegida  requireFile ( $file ) 
    {
        if ( file_exists ( $file )) {
             require  $file ;
            return  true ;
        }
        return  false ;
    }
}